from __future__ import annotations

from collections.abc import Iterable, Sequence
from math import ceil

from .model import Customer, ServiceUnit, VehicleType


class ServiceUnitBuilder:
    """
    把客户层需求拆成 service unit。

    当前项目采用的原则是：
    1. 尽量按订单保留细粒度；
    2. 不主动把多个订单装箱凑满一辆车；
    3. 只有当单条订单没有任何一种车型能同时装下时，才继续拆成多个 piece。
    """

    def build_units(
        self,
        customers: Iterable[Customer],
        vehicle_types: Sequence[VehicleType],
    ) -> list[ServiceUnit]:
        """
        构造全部 service unit。

        当前实现策略：
        1. 直接使用全部车型信息判断可承运性；
        2. 对每个客户分别拆分；
        3. 若客户有订单明细，则“一个订单一个 unit”；
        4. 若单条订单没有任何车型能同时装下，则只对这一条订单继续拆 piece；
        5. 若客户没有订单明细，才退化为按客户总需求切块；
        6. 最后统一校验拆分结果。
        """
        vehicle_types = list(vehicle_types)
        if not vehicle_types:
            raise ValueError("vehicle_types 不能为空。")

        service_units: list[ServiceUnit] = []
        for customer in customers:
            service_units.extend(
                self.split_customer_into_units(
                    customer=customer,
                    vehicle_types=vehicle_types,
                )
            )

        self.validate_units(service_units=service_units, vehicle_types=vehicle_types)
        return service_units

    def split_customer_into_units(
        self,
        customer: Customer,
        vehicle_types: Sequence[VehicleType],
    ) -> list[ServiceUnit]:
        """
        拆分单个客户。

        当前原则不是“装箱装满”，而是：
        1. 保留订单级细粒度；
        2. 不主动把多个订单合并成更大的 unit；
        3. 只在“单条订单自己没有任何车型能同时装下”时才拆 piece。
        """
        if customer.demand_weight <= 0 and customer.demand_volume <= 0:
            return []

        if not vehicle_types:
            raise ValueError("vehicle_types 不能为空。")

        orders = customer.raw_orders or []

        if not orders:
            return self._split_aggregate_customer(
                customer=customer,
                vehicle_types=vehicle_types,
            )

        service_units: list[ServiceUnit] = []
        unit_index = 1

        for order in orders:
            order_units = self._split_single_order_into_units(
                customer=customer,
                order=order,
                vehicle_types=vehicle_types,
                start_index=unit_index,
            )
            service_units.extend(order_units)
            unit_index += len(order_units)

        self._check_customer_total_preserved(customer=customer, units=service_units)
        return service_units

    def validate_units(
        self,
        service_units: Sequence[ServiceUnit],
        vehicle_types: Sequence[VehicleType],
    ) -> None:
        """
        校验拆分结果是否合理。

        这里至少检查：
        1. unit_id 是否唯一；
        2. 每个 unit 的重量和体积是否非负；
        3. 时间窗是否完整；
        4. 每个 unit 是否能被至少一种车型承运。
        """
        seen_ids: set[str] = set()

        for unit in service_units:
            if unit.unit_id in seen_ids:
                raise ValueError(f"发现重复的 unit_id: {unit.unit_id}")
            seen_ids.add(unit.unit_id)

            if unit.weight < -1e-9:
                raise ValueError(f"service unit 出现负重量: {unit.unit_id}")

            if unit.volume < -1e-9:
                raise ValueError(f"service unit 出现负体积: {unit.unit_id}")

            if unit.time_window.start_min > unit.time_window.end_min:
                raise ValueError(
                    f"service unit 时间窗不合法: {unit.unit_id}, "
                    f"{unit.time_window.start_min} > {unit.time_window.end_min}"
                )

            feasible_vehicle_exists = any(
                unit.weight <= vehicle_type.max_weight + 1e-9
                and unit.volume <= vehicle_type.max_volume + 1e-9
                for vehicle_type in vehicle_types
            )

            if not feasible_vehicle_exists:
                raise ValueError(
                    f"service unit 无法被任何车型承运: {unit.unit_id}, "
                    f"weight={unit.weight}, volume={unit.volume}"
                )

    def _split_single_order_into_units(
        self,
        customer: Customer,
        order: dict[str, object],
        vehicle_types: Sequence[VehicleType],
        start_index: int,
    ) -> list[ServiceUnit]:
        """
        把单条订单拆成一个或多个 unit。

        默认情况：
        - 一条订单对应一个 unit。

        只有当订单自己没有任何车型能同时装下时：
        - 才按比例切成多个 piece；
        - 每个 piece 仍然保留订单来源。
        """
        order_id = str(order["order_id"])
        weight = float(order["weight"])
        volume = float(order["volume"])

        if weight < -1e-9 or volume < -1e-9:
            raise ValueError(f"订单出现负重量或负体积: order_id={order_id}")

        if self._can_any_vehicle_carry(weight=weight, volume=volume, vehicle_types=vehicle_types):
            return [
                ServiceUnit(
                    unit_id=f"C{customer.customer_id:03d}_U{start_index:03d}",
                    customer_id=customer.customer_id,
                    weight=weight,
                    volume=volume,
                    time_window=customer.time_window,
                    is_green=customer.is_green,
                    source_order_ids=[order_id],
                )
            ]

        piece_count = self._piece_count_to_fit_any_vehicle(
            weight=weight,
            volume=volume,
            vehicle_types=vehicle_types,
        )

        units: list[ServiceUnit] = []
        piece_weight = weight / piece_count
        piece_volume = volume / piece_count

        for offset in range(piece_count):
            units.append(
                ServiceUnit(
                    unit_id=f"C{customer.customer_id:03d}_U{start_index + offset:03d}",
                    customer_id=customer.customer_id,
                    weight=piece_weight,
                    volume=piece_volume,
                    time_window=customer.time_window,
                    is_green=customer.is_green,
                    source_order_ids=[f"{order_id}_P{offset + 1:02d}"],
                )
            )

        return units

    def _split_aggregate_customer(
        self,
        customer: Customer,
        vehicle_types: Sequence[VehicleType],
    ) -> list[ServiceUnit]:
        """
        当客户没有 raw_orders 时，按客户总需求切块。

        这是退化情况，不是首选。
        只有缺少订单级明细时才使用。
        """
        part_count = self._piece_count_to_fit_any_vehicle(
            weight=customer.demand_weight,
            volume=customer.demand_volume,
            vehicle_types=vehicle_types,
        )

        unit_weight = customer.demand_weight / part_count
        unit_volume = customer.demand_volume / part_count

        service_units: list[ServiceUnit] = []
        for index in range(1, part_count + 1):
            service_units.append(
                ServiceUnit(
                    unit_id=f"C{customer.customer_id:03d}_U{index:03d}",
                    customer_id=customer.customer_id,
                    weight=unit_weight,
                    volume=unit_volume,
                    time_window=customer.time_window,
                    is_green=customer.is_green,
                    source_order_ids=[],
                )
            )

        self._check_customer_total_preserved(customer=customer, units=service_units)
        return service_units

    def _can_any_vehicle_carry(
        self,
        weight: float,
        volume: float,
        vehicle_types: Sequence[VehicleType],
    ) -> bool:
        """检查是否存在至少一种车型能同时装下给定重量和体积。"""
        return any(
            weight <= vehicle_type.max_weight + 1e-9
            and volume <= vehicle_type.max_volume + 1e-9
            for vehicle_type in vehicle_types
        )

    def _piece_count_to_fit_any_vehicle(
        self,
        weight: float,
        volume: float,
        vehicle_types: Sequence[VehicleType],
    ) -> int:
        """
        计算最少要拆成多少份，才能让每一份都能被至少一种车型同时装下。

        对于拆成 n 份后的 piece：
        - 每份重量 = weight / n
        - 每份体积 = volume / n

        只要存在某种车型同时满足：
        - weight / n <= max_weight
        - volume / n <= max_volume

        就说明这一份是可承运的。
        """
        if self._can_any_vehicle_carry(weight=weight, volume=volume, vehicle_types=vehicle_types):
            return 1

        candidate_piece_counts = [
            max(
                ceil(weight / vehicle_type.max_weight) if weight > 0 else 1,
                ceil(volume / vehicle_type.max_volume) if volume > 0 else 1,
            )
            for vehicle_type in vehicle_types
        ]

        return min(candidate_piece_counts)

    def _check_customer_total_preserved(
        self,
        customer: Customer,
        units: Sequence[ServiceUnit],
    ) -> None:
        """
        检查拆分后的 unit 总量是否与原客户总需求一致。
        """
        total_weight = sum(unit.weight for unit in units)
        total_volume = sum(unit.volume for unit in units)

        if abs(total_weight - customer.demand_weight) > 1e-6:
            raise ValueError(
                f"客户 {customer.customer_id} 拆分后总重量不守恒: "
                f"{total_weight} != {customer.demand_weight}"
            )

        if abs(total_volume - customer.demand_volume) > 1e-6:
            raise ValueError(
                f"客户 {customer.customer_id} 拆分后总体积不守恒: "
                f"{total_volume} != {customer.demand_volume}"
            )
